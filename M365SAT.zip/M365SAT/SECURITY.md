Me as a Vulnerability Assessor take security very seriously. Take in mind that this program can execute other powershell scripts as well. This means it can even execute malicious scripts unknownwillingly. Please ensure you only download the GitHub package from my repo to ensure security. I am not responsible for any damage or loss of files if that is the case. 

Please use the security best-practices as followed:
-   Use least privilege on the account you audit with. So only the necessary privileges for the audit being used on the account you are provided with,
-   Write-Protect the inspector folder for unauthorized access to make sure your inspectors are not being overwritten with malicious code,
-   Do not place, unless it is trusted, any PowerShell script into the inspectors folders,
-   Do not download M365SAT from external websites, as they might have malicious stuff with them injected into the scripts. Only download M365SAT from my GitHub page,
-   If you have bought this software from someone, immediately ask for a refund as this software is free-of-charge.